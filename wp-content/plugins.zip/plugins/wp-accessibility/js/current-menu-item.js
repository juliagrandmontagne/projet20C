(function ($) {
	$(function() {
		$( '.current-menu-item a, .current_page_item a' ).attr( 'aria-current', 'page' );
	});
}(jQuery));
